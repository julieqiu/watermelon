FOLDER_TEMPLATE = 'templates'
FOLDER_STATIC = 'static'
