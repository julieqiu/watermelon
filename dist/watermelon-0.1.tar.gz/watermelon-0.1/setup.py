from setuptools import setup

setup(name='watermelon',
      version='0.1',
      description='watermelon webframework',
      url='https://github.com/julieqiu/watermelon',
      author='Julie Qiu',
      author_email='julieyeqiu.com',
      packages=['watermelon'],
      zip_safe=False)
